package ex01_first;

public class Test {
//	main 템플릿
//	main 작성 후 ctrl + spacebar
//	public static void main(String[] args) {
//		
//	}
	public static void main(String[] args) {
		// main 함수
		// 파일을 실행하면 main함수 안에 있는 코드가 실행이 된다.
		// 명령이 끝날 때 마다 세미콜론 반드시 찍기(;)
		System.out.println("Hello World, Welcome to Java");
		System.out.print("Hello World"); // 줄바꿈 없음
		System.out.println(""); // 줄바꿈
		System.out.printf("Welcome to Java"); // 줄바꿈 없음
		System.out.println("");
		System.out.println("Hello World"); // 자동 줄바꿈
		System.out.println("Welcome to Java");
		// sysout 템플릿
		// sysout작성 후 ctrl + spacebar
		System.out.println(1+2*3*4/5%2);
		
		// TODO : 해야할 일이 있습니다. 추후에 하드코딩을 개선해야합니다.
		
		// FIXME : 런타임 오류 남...바꿔야함 빨리빨리;;;;;;;;
		
		// XXX : 조졌네...하드코딩으로 변경 ㄱ
		// XXX : 아니 하드코딩을 수정하라고...
	}
}
